package com.tnsif.springdemo;

public interface Mobile {
	
	void call();
	void data();
	
}
